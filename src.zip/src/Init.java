import java.io.File;

public class Init {
	public static void main(String[] args) throws Exception {	
		File file = new File("C:");
		Parse.parseFiles(file, true);
	}  
}
