package compilerUtil;

import java.lang.reflect.Method;
import java.util.Map;

public class Main {

	public static JavaStringCompiler compiler;

	static final String SINGLE_JAVA = "/* a single java class to one file */  "
			+ "public class User {     										  "
			+ "    public String id;                                    	  "
			+ "    public void setId(String id) {                             "
			+ "        this.id=id;		                                      "
			+ "    }                                                          "
			+ "    public String getId() {                                 	  "
			+ "        return this.id;                                    	  "
			+ "    }                                                          "
			+ "}                                                              ";


	public static void main(String[] args) throws Exception {
		compiler = new JavaStringCompiler();
		Map<String, byte[]> results = compiler.compile("User.java", SINGLE_JAVA);

		Class<?> clazz = compiler.loadClass("User", results);                                                                                                                                       
			Method method0 = clazz.getMethod("setId",new Class[]{String.class});   
			Object obj = clazz.newInstance();
			method0.invoke(obj,new Object[]{"123"});
			Method method = clazz.getMethod("getId");      
			Object result=method.invoke(obj);
			System.out.println(result);		
	}	
}
