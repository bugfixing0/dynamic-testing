
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Stack;


public class TestGenerator {
	public static String generateTestInstance(String inFileName, String outFileName, String className, String[] parametersList, boolean isWrite) throws IOException {
		String parameterName = " ";
		for(int i=0;i<parametersList.length-1;i++){
			parameterName = parameterName + (parametersList[i]+".class,");
		}
		parameterName = parameterName + (parametersList[parametersList.length-1]+".class");
		ArrayList<String> inLinesList = getLines(inFileName);
		ArrayList<String> outLinesList = new ArrayList<String>();
		ArrayList<Integer> testFuncIndexList = getTestFuncIndex(inLinesList);
		testFuncIndexList.add(inLinesList.size());
         
		 
		outLinesList.add("import java.lang.reflect.InvocationTargetException;");
		outLinesList.add("import java.lang.reflect.Method;");
		outSomeLines(inLinesList,outLinesList,0,testFuncIndexList.get(0));	
		outLinesList.add("public class "+className+"_Test {");

		outLinesList.add("private  String className ;");
		outLinesList.add("private  String methodName ;");
		outLinesList.add("public int verify(String className,String methodName)  {");
		outLinesList.add("this.className=className;");
		outLinesList.add("this.methodName=methodName;");
		
		
		for(int i=0;i<testFuncIndexList.size()-3;i++){
			outLinesList.add("try {");
			outLinesList.add("test"+i+"();");
			outLinesList.add("} catch (Throwable e) {");
			outLinesList.add("return "+ (i+1)+";");
			outLinesList.add("}");
		}		
		
		outLinesList.add("return 0;");
		outLinesList.add("}");
		
		for(int i=1;i<testFuncIndexList.size()-1;i++){
			ArrayList<Integer> keyIndexList = getKeyIndex(inLinesList, testFuncIndexList.get(i), testFuncIndexList.get(i+1));
//			System.out.println(keyIndexList.size());
			if(keyIndexList.size()==1){
				outSomeLines(inLinesList,outLinesList,testFuncIndexList.get(i), keyIndexList.get(0));	
				String parmeter = getParameter(inLinesList.get(keyIndexList.get(0)-1));
				outLinesList.add("Class<?> clazz = Class.forName(className); ");
				outLinesList.add("Method method = clazz.getMethod(methodName,new Class[]{"+parameterName+"}); " );
				outLinesList.add("Object result=method.invoke(clazz,new Object[]{" + parmeter +"});");
				outLinesList.add("assertEquals(result, "+getActualValue(inLinesList.get(keyIndexList.get(0)))+");");
				outSomeLines(inLinesList,outLinesList,keyIndexList.get(0)+1, testFuncIndexList.get(i+1));	
			}else if(keyIndexList.size()>1){
				outSomeLines(inLinesList,outLinesList,testFuncIndexList.get(i), keyIndexList.get(0));	
				String parmeter = getParameter(inLinesList.get(keyIndexList.get(0)+1));
				outLinesList.add("try { ");
				outLinesList.add("Class<?> clazz = Class.forName(className); ");
				outLinesList.add("Method method = clazz.getMethod(methodName,new Class[]{"+parameterName+"}); " );
				outLinesList.add("method.invoke(clazz,new Object[]{" + parmeter +"});");
				outLinesList.add("} catch(InvocationTargetException ex) {");
				outLinesList.add("assertThrownBy(className, ex.getTargetException());");
				outLinesList.add("}");
				outLinesList.add("}");
			}else if(keyIndexList.size()==0){
				outSomeLines(inLinesList,outLinesList,testFuncIndexList.get(i),testFuncIndexList.get(i)+1);	
				outLinesList.add("}");					
			}					
		}
		outLinesList.add("}");
		return getStringJavaFile(outFileName, outLinesList,isWrite);		
	}
	public static ArrayList<Integer> getTestFuncIndex(ArrayList<String> linesList) throws IOException{
		ArrayList<Integer> testFuncIndexList = new ArrayList<Integer>();
		for(int i=0;i<linesList.size();i++){
			if (linesList.get(i).contains("test")||linesList.get(i).contains("extends")) {
				testFuncIndexList.add(i);
			}
		}
		return testFuncIndexList;		
	}
	public static ArrayList<Integer> getKeyIndex(ArrayList<String> linesList,int startIndex,int endIndex){
		ArrayList<Integer> keyIndexList = new ArrayList<Integer>();
		for(int i=startIndex;i<endIndex;i++){
			if (linesList.get(i).contains("try") ||
				linesList.get(i).contains("catch")||
				linesList.get(i).contains("assert")) {
				keyIndexList.add(i);
			}
		}
		return keyIndexList;
	}
	public static ArrayList<String> getLines(String inFileName) throws IOException{
		ArrayList<String> linesList = new ArrayList<String>();
		BufferedReader bufReader = new BufferedReader(new FileReader(inFileName));
		String line;
		while ((line = bufReader.readLine()) != null) {
			if(!(line.contains("@") )){
				linesList.add(line);
			}			
		}
		bufReader.close();
		return linesList;
	}
	public static String getStringJavaFile(String outFileName,ArrayList<String> linesList,boolean isWrite) throws IOException{
		String result = "";
		if (isWrite == true){
			FileWriter fileWriter = new FileWriter(outFileName);
			BufferedWriter bufWriter = new BufferedWriter(fileWriter);
			
			for(int i=0;i<linesList.size();i++){
				bufWriter.write(linesList.get(i));
				bufWriter.newLine();
			}
			fileWriter.flush();
			bufWriter.flush();
			
			bufWriter.close();
			fileWriter.close();
		}
			for(int i=0;i<linesList.size();i++){
			result = result + (linesList.get(i)+"\n");
			
		}
		return result;
	}
	
	private static String getActualValue(String string) {
		String result="";
		Stack<Character> stack = new Stack<Character>();
		int startIndex = 0 ;
		if(string.contains(",")){
			stack.add('(');
			startIndex = string.lastIndexOf(",")+1;
		}else{
			startIndex = string.indexOf("(");
		}
		for(int i=startIndex;i<string.length();i++){
			if(string.charAt(i)=='('){
				if(!stack.isEmpty()){
					result = result+string.charAt(i);
				}				
				stack.add(string.charAt(i));
			}else if(string.charAt(i)==')'){
				stack.pop();
				if(!stack.isEmpty()){
					result = result+string.charAt(i);
				}else{
					return result;
				}
			}else{
				result = result+string.charAt(i);
			}
		}
		return result;
	}
	private static String getParameter(String string) {
		String result="";
		Stack<Character> stack = new Stack<Character>();
		int startIndex = string.indexOf("(") ;
		for(int i=startIndex;i<string.length();i++){
			if(string.charAt(i)=='('){
				if(!stack.isEmpty()){
					result = result+string.charAt(i);
				}				
				stack.add(string.charAt(i));
			}else if(string.charAt(i)==')'){
				stack.pop();
				if(!stack.isEmpty()){
					result = result+string.charAt(i);
				}else{
					return result;
				}
			}else{
				result = result+string.charAt(i);
			}
		}
		return result;
	}
	private static void outSomeLines(ArrayList<String> inLinesList,ArrayList<String> outLinesList,int startIndex,int endIndex) {
		for(int i=startIndex;i<endIndex;i++){
			
			outLinesList.add(inLinesList.get(i));
		}		
	}
}
