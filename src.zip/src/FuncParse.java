import java.util.ArrayList;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Modifier;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.Type;

public class FuncParse extends ASTVisitor {  
	private String filePath;
	public static String parameter;
	public static ArrayList<String> parameterNameList = new ArrayList<String>();
	public static String returntype;
	public static String funname;
	public static String funpath;
	private  boolean isInsertToDB;
	public FuncParse(String filePath, boolean isInsertToDB) {
		super();
		this.filePath = filePath;
		this.isInsertToDB = isInsertToDB;
	}
	@Override 
	public boolean visit(MethodDeclaration node) {  
		if( Modifier.isStatic(node.getModifiers()))
		{
			String parameter,returntype,funname,funpath;
			try{
				parameter ="";
				parameter += "[";
				for (Object param : node.parameters()) {
					parameterNameList.add(((SingleVariableDeclaration) param).getName().toString());
					parameter += ((SingleVariableDeclaration) param).getType().toString() + ",";
				}
				if (parameter.endsWith(",")) {
					parameter = parameter.substring(0, parameter.length() - 1);
				}
				parameter += "]";
				Type  returntype2= node.getReturnType2();
				if(returntype2 == null)
				{
					returntype="null";
				}else
				{
					returntype=returntype2.toString();
				}
				funname = node.getName().toString();
				funpath =  filePath;

				int startIndex=funpath.lastIndexOf("src\\");
				int endIndex=funpath.lastIndexOf(".java");
				funpath = funpath.substring(startIndex+4,endIndex);
				funpath = funpath.replace('\\', '.');
				FuncParse.parameter=parameter;
				FuncParse.returntype=returntype;
				FuncParse.funname=funname;
				FuncParse.funpath=funpath;
				if(isInsertToDB==true){
					String sql="insert into funstatic(parameter,returntype,funname,funpath) values('"+parameter +"','"+returntype +"','"+funname +"','"+ funpath+"')";
					DBUtil.insert(sql);
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return true;  
	}  
}  