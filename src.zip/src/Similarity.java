

import java.util.ArrayList;

public class Similarity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String functionAName;
		String functionBName;
		ArrayList<String> functionAParameters = new ArrayList<String>();
		ArrayList<String> functionBParameters = new ArrayList<String>();
		functionAName = "getAbc";
		functionBName = "getBcd";
		functionAParameters.add("splitByInteger");
		functionAParameters.add("justTheNum");
		functionBParameters.add("matchInteger");
		functionBParameters.add("justTheString");
		float result = similarity(functionAName, functionBName, functionAParameters, functionBParameters);
		System.out.println(result);
	}
	
	public static float similarity(String functionAName, String functionBName,
			ArrayList<String> functionAParameters, ArrayList<String> functionBParameters){
		float result = 0;
		result = (float) (similarityAB(functionAName, functionBName) * 0.5);
		for(int i=0;i<functionAParameters.size();i++){
			float temp =(float) (similarityAB(functionAParameters.get(i), functionBParameters.get(i)) 
					* 0.5 * (1.0/functionAParameters.size()));
			System.out.println(temp);
			result = result + temp;
		}
		return result;
	}
	
	public static float similarityAB(String A, String B){
		float result = 0;
		float numEqualWord=0;
		ArrayList<String> listA = splitByUpcase(A);
		ArrayList<String> listB = splitByUpcase(B);
		for(int i=0;i<listA.size();i++){
			for(int j=0;j<listB.size();j++){
				if(isSimilar(listA.get(i),listB.get(j))){
					numEqualWord = numEqualWord + 2;
				}
			} 
		}
		result = numEqualWord/(listA.size()+listB.size());
		return result;
	}
	private static boolean isSimilar(String stringA, String stringB) {
		// TODO Auto-generated method stub
		int numEqualChara=0;
		for (int i = 0; i < stringA.length() && i < stringB.length(); i++) {
			if(stringA.charAt(i) == stringB.charAt(i)){
				numEqualChara++;
			}else{
				break;
			}
		}
		if(numEqualChara == stringA.length() || numEqualChara ==stringB.length() || numEqualChara>(0.5)* Math.max(stringA.length(), stringB.length())){
			return true;
		}
		return false;
	}

	public static ArrayList<String> splitByUpcase(String string){
		ArrayList<String> list = new ArrayList<String>();
		int lastIndex = 0;
		for(int i=0;i<string.length();i++){
			if(string.charAt(i)>='A' && string.charAt(i)<='Z'){
				list.add(string.substring(lastIndex, i).toLowerCase());
				lastIndex = i;
			}
		}
		list.add(string.substring(lastIndex, string.length()).toLowerCase());
		return list;
	}

}
