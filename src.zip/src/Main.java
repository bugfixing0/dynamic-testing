public class Main {
	public static void main(String[] args) throws Exception {	

		
		
		System.out.println("*****");
		Match.match("C:\\test\\staticFunc\\class402.java");
		System.out.println(Match.numMatchParameterReturn + " " + Match.numMatchName + " " +Match.numMatchTest);
		
		System.out.println(Match.numFirstNotMatch);
		
		
	}  
	
}
