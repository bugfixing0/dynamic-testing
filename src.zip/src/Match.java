import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;

import org.eclipse.core.internal.resources.Project;

import compilerUtil.JavaStringCompiler;

public class Match {
	public static int numMatchParameterReturn = 0;
	public static int numMatchName = 0;
	public static int numMatchTest = 0;
	public static int numFirstNotMatch = 0;
	
	public static ArrayList<String> search(String fileName){
		File file = new File(fileName);
		Parse.parseFile(file,false);		
		String sql = "select * from funstatic where parameter='"+FuncParse.parameter+"' and returntype='"+FuncParse.returntype+"'";
		return DBUtil.select(sql);
	}
	
	
	public static void match(String fileName) throws Exception{
		ArrayList<String> result =search(fileName);
		numMatchParameterReturn = result.size()/4;
		int startIndex = fileName.lastIndexOf("\\");
		if(startIndex == -1){
			startIndex = 0;
		}else{
			startIndex = startIndex + 1;
		}
		int endIndex = fileName.lastIndexOf(".java");
		String className = fileName.substring(startIndex, endIndex);	
		ArrayList<String> parameterNameList = FuncParse.parameterNameList;
		String[] parametersList = FuncParse.parameter.substring(1, FuncParse.parameter.length()-1).split(",");
		
		
		String stringJavaFile = TestGenerator.generateTestInstance(className + "_ESTest.java", className + "_Test.java", className, parametersList,true);
		
		JavaStringCompiler compiler = new JavaStringCompiler();
		Map<String, byte[]> results = compiler.compile(className + "_Test.java", stringJavaFile);
        
	    Class<?> clazz = compiler.loadClass(className + "_Test", results);
		    
	  	Method method = clazz.getMethod("verify", String.class, String.class);
	  		
		 for (int i=0;i<result.size();i=i+4){
			float similarity = Similarity.similarityAB(FuncParse.funname, result.get(i+2));
			if(similarity>=0.25)
			{
				numMatchName++;
			//System.out.println("similarity "+similarity);
			int flag = (int) method.invoke(clazz.newInstance(),result.get(i+3), result.get(i+2));
			//System.out.print(tempBoolean+"\t");
			
			if(flag == 0){
				numMatchTest++;
				System.out.println(result.get(i+3)+"\t"+result.get(i+2)+"\t Match");
			}else{
				if(flag == 1){
					numFirstNotMatch++;
				}
				//System.out.println(result.get(i+3)+"\t"+result.get(i+2)+"\t Not Match");
			}
			}
		}
	}
}
