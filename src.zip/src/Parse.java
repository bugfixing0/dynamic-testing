import java.io.File;

import org.eclipse.jdt.core.dom.CompilationUnit;

public class Parse {  
	public static void parseFiles(File file,boolean isInsertToDB){
		File[] files = file.listFiles();
		for(File a:files){
			if(a.isDirectory()){
				parseFiles(a,isInsertToDB);
			}else{
				parseFile(a,isInsertToDB);
			}
		}
	}
	public static void parseFile(File file,boolean isInsertToDB){
		CompilationUnit comp = AstUtil.getCompilationUnit(file.getAbsolutePath());        
		FuncParse visitor = new FuncParse(file.getAbsolutePath(),isInsertToDB);          
		comp.accept(visitor); 
	}
} 


